 MyModel.py : example template for runtime model
 requirements.txt : dependencies
 .s2i/environment : add required parameters here

You can also add a setup.py rather than a requirements.txt

